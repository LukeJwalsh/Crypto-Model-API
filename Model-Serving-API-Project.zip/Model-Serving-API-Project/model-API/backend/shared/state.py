from typing import Any, Dict


MODEL_REGISTRY: Dict[str, Dict[str, Any]] = {}

